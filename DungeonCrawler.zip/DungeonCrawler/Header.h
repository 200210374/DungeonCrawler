#pragma once

#include <iostream>

#include <fstream>
#include <cstdlib> 
#include <iomanip>

#include <string>

using namespace std;

void PrintMenu() {



	cout << "\n\t\Menu\n\n"

	

		<< "1. Play dungeon crawler\n"
		<< "2. controls\n"
		<< "4. Quit\n\n"

		"\tInstructions\n\n"
		<< "To move use w,a,s,d keys\n"
		<< "Pres h and enter to heal\n"
		<< "Pres j and enter to cast defense up+\n"
		<< "Pres n and enter to cast damage up+\n"


		<< "\nEnter your choice: ";


}












	











	