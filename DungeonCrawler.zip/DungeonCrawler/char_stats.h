#pragma once


#include <iostream>

#include <fstream>
#include <cstdlib> 
#include <iomanip>

#include <string>


void statsMenu() {



	cout << "\n\t\Class Menu\n\n"
		<< "1. Warrior\n"
		<< "2. Mage\n"
		<< "3. Rouge\n"
		<< "4. Knight\n"
		<< "5. Archer\n"
		<< "6. Quit\n\n"
		<< "Enter your choice: ";



}


